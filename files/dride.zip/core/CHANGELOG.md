## [0.12.2](https://github.com/dride/dride-core/compare/v0.12.1...v0.12.2) (2018-09-03)


### Bug Fixes

* **ble:** fix button notification ([687c893](https://github.com/dride/dride-core/commit/687c893))
* **record:** remove empty files on decode ([dc87116](https://github.com/dride/dride-core/commit/dc87116))

<a name="0.12.1"></a>
## [0.12.1](https://github.com/dride/dride-core/compare/v0.12.0...v0.12.1) (2018-05-01)


### Bug Fixes

* **impulseButton:** fix support for new raspivid file ([5837af4](https://github.com/dride/dride-core/commit/5837af4))

<a name="0.12.0"></a>
# [0.12.0](https://github.com/dride/dride-core/compare/v0.11.0...v0.12.0) (2018-04-24)


### Features

* **led module:** Native LED control ([50bf1cf](https://github.com/dride/dride-core/commit/50bf1cf))

<a name="0.11.0"></a>
# [0.11.0](https://github.com/dride/dride-core/compare/v0.10.1...v0.11.0) (2018-04-08)


### Features

* **live:** Add live stream view for drideOS ([8a72d07](https://github.com/dride/dride-core/commit/8a72d07))

<a name="0.10.1"></a>
## [0.10.1](https://github.com/dride/dride-core/compare/v0.10.0...v0.10.1) (2018-04-01)


### Bug Fixes

* **video:** fix filename fix in ensureAllClipsAreDecoded ([250ae10](https://github.com/dride/dride-core/commit/250ae10))

<a name="0.10.0"></a>
# 0.10.0 (2018-03-25)


### Bug Fixes

* **release:** add missing plugins ([eeb0fe3](https://github.com/dride/dride-core/commit/eeb0fe3))
* **record:** allow encode after button click ([2348cb7](https://github.com/dride/dride-core/commit/2348cb7))
* **settings:** cast boolean values ([6ad1d90](https://github.com/dride/dride-core/commit/6ad1d90))
* **record:** fix encoding block and encoding loop ([8a48455](https://github.com/dride/dride-core/commit/8a48455))
* **video:** fix encoding orchestration issues ([8d46d2e](https://github.com/dride/dride-core/commit/8d46d2e))
* **button:** fix issues with state after click ([cd241ea](https://github.com/dride/dride-core/commit/cd241ea))


### Features

* **release:** Add .releaserc ([a51343c](https://github.com/dride/dride-core/commit/a51343c))
